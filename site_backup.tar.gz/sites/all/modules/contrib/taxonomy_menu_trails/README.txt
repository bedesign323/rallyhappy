Taxonomy Menu Trails.

Quick start
-----------

Configure module for each node type you want to expand the menu:
- Go to the node type settings page
- Switch to "Taxonomy Menu Trails" vertical tab
- Enable at least one term reference field
- Save settings

Full documentation
------------------

Visit this page for detailed documentation: http://drupal.org/node/1602532
Please check FAQ before posting issues: http://drupal.org/node/1602684