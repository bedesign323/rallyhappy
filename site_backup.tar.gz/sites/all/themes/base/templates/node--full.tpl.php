<div class="full">
	<h1 class="title"><?php echo $title; ?></h1>
	<div class="cvideo">
		<?php echo $video; ?>
		
	</div>
	<div class="info">
		
		
		<div class="desc"><?php echo $body; ?></div>
		<div class="tags"><?php echo $sections; ?><?php echo $tags; ?></div>
		<div class="social-links">
			<h2>Share This Post</h2>
			<?php echo $service_links; ?>
		</div>
	</div>
	<div class="divider"></div>
</div>
