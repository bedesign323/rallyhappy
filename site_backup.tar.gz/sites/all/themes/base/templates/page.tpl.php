
<div id="nav">
	<div class="menu-toggle">Menu</div>
	<ul>
		<li><a href="" data-scroll-nav="1">What is this?</a></li>
		<li><a href=""data-scroll-nav="2">The Declaration</a></li>
		<li><a href=""data-scroll-nav="3">Kate Gregg</a></li>
		<li><a href=""data-scroll-nav="4">Join the pursuit</a></li>
		<li><a href=""data-scroll-nav="5">Connect</a></li>
	</ul>
</div>

<div id="intro">
	<div id="logo"><img src="sites/all/themes/base/images/KG4H-logo.svg" alt=""></div>
	<div id="banner"><img src="sites/all/themes/base/images/KG4H-banner.svg" alt=""></div>
</div>
<div id="bg-image"></div>

<div id="main-container">
	<div class="main">
		<?php print render($page['content']); ?>

		<div class="section dark"  data-scroll-index="1">
				
				<p class="big center"><strong>Happiness:</strong> an indiependent social movement since 1776</p>
		</div>
		
		<div class="section med">
			<div class="inner">
				<div class="quote">

					<p class="big">We hold these truths to be self-evident, that all people are created equal, that they are endowed by their Creator with certain unalienable Rights, that among these are Life, Liberty and the <strong>pursuit of Happiness.</strong></p>
					<div class="author">- The Declaration of Independence</div>
				</div>
			</div>
		</div>

		<div class="section" data-scroll-index="2">
			<div class="section-header">
				<h1>The Declaration of Happiness</h1>
				<div class="date">July 4<sup>th</sup>, 2014</div>
				<div class="stars"><img src="sites/all/themes/base/images/KG4H-stars.svg" alt=""></div>
			</div>
			<div class="inner">
				<p>When in the course of human events, dissention threatens a precious gift; the beneficiaries of that gift must take a stand. Eleven score and nine years ago, our fathers declared Happiness an unalienable right. They dared to dream, and then, they revolutionized nationhood. What many dismissed as utopic, they brought into reality. The United States of America came to represent a bona fide place of happiness. Our American Dream has inspired millions of people around the world. In America, anything is possible. </p>
				<p>That’s not to say we’ve never faltered. Even in our brief history, we have endured trying times. America is not perfect. Thankfully, Americans are perseverant. In moments of crisis, visionaries rise up in support of shared beliefs. Through their triumphs, we evolve. America is forever strengthening and refining her identity. We are a remarkable people.</p>
				<p>Unfortunately, America seems to have lost her way. We are frustrated by the cycle of blame and shame. We are tired of focusing on what appears wrong, instead of focusing on what feels right. We are disappointed by attacks on our differences that overshadow our common bond. None of this serves us. Fortunately, these circumstances do not define us, we do. We are Americans.</p>
				<p>The American beacon will not extinguish on our watch. This Independence Day, we reignite a solution sanctioned in 1776: the pursuit of Happiness. Since ancient times, happiness has been considered "the meaning and the purpose of life, the whole aim and end of the human existence."<sup>1</sup> Accordingly, our founders dedicated an entire nation to Happiness. Countless brave souls have perished in protecting this principle. Let us rise up in support of Happiness. Let us honor their legacy and preserve our future. </p>
				<p>History demonstrates that happiness can be more readily achieved when like-minded people band together to inspire each other’s pursuit.<sup>2</sup>  </p>

				<p class="big">In that spirit, we proudly publish and declare, that we strive to: 1) live happily, and 2) encourage and empower others to live happily. Together, we can restore Happiness to its rightful place as an American priority.</p>
				<p class="big center">Happiness is the truth.</p>

				<div class="footnote">
					<div><sup>1</sup> Aristotle, Greek Philosopher  (384 – 322 B.C.E)</div>
					<div><sup>2</sup> Epicurus, Greek Philosopher (341 – 270 B.C.E.)</div>
				</div>

				<div class="banner"><img src="sites/all/themes/base/images/KG4H-banner.svg" alt=""></div>
			</div>
		</div>

		<div class="section dark">
			<div class="inner center">

				<div class="join-teaser">
					Do you support Happiness? Then why not<br /><br /> <a href="#" class="btn big">join the pursuit!</a>
				</div>
			</div>
		</div>

		<div class="section med" data-scroll-index="3">
			<div class="section-header">
				<h1>Kate Gregg</h1>
			</div>
			<div class="inner">
				<div class="quote"><p>"I believe that leaders come in all shapes and sizes. Your life is your example. Right now, there are so many amazing people doing incredible things. They are living their happiness and lighting the way for others to follow. Individually, each one is an inspiration. Collectively, they could change the world. I believe these people need a voice. And so, I created an independent social movement to unite people in Happiness across America. It’s time to stop bashing what we hate, and start promoting what we love. This small shift delivers a giant impact. With the help of my friends, I am standing up for Happiness. I hope you will join me. I believe in the pursuit of Happiness. I believe in you."</p>
					<div class="author">- Kate Gregg</div>
				</div>
				<div class="stars"><img src="sites/all/themes/base/images/KG4H-stars.svg" alt=""></div>
				<br /><br />
				<p>Kate Gregg was born in Washington, DC. She graduated magna cum laude from Duke University and earned her law degree from UCLA. She is licensed to practice law in the state of California. Kate’s experience includes interning at the White House, political consulting and fundraising, advising senior U.S. Congressmen, and helping prominent U.S. House, Senate, and Presidential campaigns. Kate considered public office before deciding to leave politics. Today, she lives in Los Angeles, where she advocates Happiness as a powerful force for change. She runs a passion project group, Infinity Projects. And her personal passions include hospitality, modeling, travel, writing, and supporting non-profits like Team Rubicon and UNICEF’s Next Generation. </p>
			</div>
		</div>

		<div id="join" class="section dark" data-scroll-index="4">
			<div class="section-header">
				<h1>Join the Pursuit</h1>
			</div>
			<div class="inner">
				<p class=""> We are gathring sigantures of people who want to help restore Happiness to its rightful place as an American priority. We will never sell your info or send you spam (promise!) There is tremendous strength in numbers. So, help us show the wold that Happiness is back!</p>
				
				<?php
				  print render(node_view(node_load(4), 'full', NULL));
				?>
			</div>
		</div>

		<div class="section xdark">
			<div class="section-header">
				<h1>Share the Happy!</h1>
			</div>
			<div class="inner">
				<p class="center big">Help us spread this movment by sharing</p>
				<div class="follow-icons">
					<a href="https://twitter.com/home?status=I%20support%20%23rallyhappy%20http://rallyhappy.org" class="icon-twitter"></a>
					<a href="https://www.facebook.com/sharer/sharer.php?u=rallyhappy.org" class="icon-facebook"></a>
					<a href="https://plus.google.com/share?url=rallyhappy.org" class="icon-googleplus"></a>
				</div>
				<br /><br />
				<p class="center">
					<a href="/downloads/Happy_Art_pack.zip" class="btn big">Download the Happy Art Pack</a>
				</p>
			</div>
		</div>

		<div class="section dark">
			<div class="section-header">
				<h1>Follow Happy!</h1>
			</div>
			<div class="inner">
				<p class="center big">Strengthen our movement by following: @rallyhappy</p>
				<div class="follow-icons">
					<a href="http://twitter.com/rallyhappy" class="icon-twitter"></a>
					<a href="http://facebook.com/rallyhappy" class="icon-facebook"></a>
					<a href="http://instagram.com/rallyhappy" class="icon-instagram"></a>
				</div>
			</div>
		</div>

		<div class="section med" data-scroll-index="5">
			<div class="section-header">
				<h1>Get in touch.</h1>
			</div>
			<div class="inner">
				<p class="big">We greatly appreciate your efforts. If you would like to do more, please contact <a href="mailto:hello@rallyhappy.com">hello@rallyhappy.com</a></p>
				<br /><br /><br />
				<div class="banner big"><img src="sites/all/themes/base/images/KG4H-banner.svg" alt="">
			</div>
		</div>

	</div>
</div>

<div id="footer-container">
	<div class="section">
		<div class="inner">
			<div class="footer-main"><?php print render($page['footer_main']); ?></div>
			<div class="footer-left"><?php print render($page['footer_left']); ?></div>
			<div class="footer-right"><?php print render($page['footer_right']); ?></div>
		</div>
		<div class="copy center">
			&copy; <?php echo date('Y') . ' ' . $site_name; ?>
		</div>
	</div class="section">
</div>
